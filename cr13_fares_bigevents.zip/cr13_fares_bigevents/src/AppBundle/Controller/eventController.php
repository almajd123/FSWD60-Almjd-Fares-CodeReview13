<?php

namespace AppBundle\Controller;

use AppBundle\Entity\events;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;

class eventController extends Controller
{
    /**
     * @Route("/", name="homepage")
     */
    public function listAction()
    {
        $events = $this->getDoctrine()
        ->getRepository('AppBundle:events')
        ->findAll();

        return $this->render('events/index.html.twig', array(
            'events' => $events
        ));
    }


    /**
     * @Route("/events/create", name="events_create")
     */
    public function createAction(Request $request)
    {
        $event = new events;
        $form = $this->createFormBuilder($event)
        ->add('eventName', TextType::class, array('label' => 'Event Name', 'attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
        ->add('eventDate', DateTimeType::class, array('label' => 'Event Date', 'widget' => 'single_text', 'attr' => array('class' => 'form-control', 'style' => 'margin:0 0 15px 0px')))
          ->add('eventImg', TextType::class, array('label' => 'Event image link', 'attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
        ->add('eventDesc', TextareaType::class, array('label' => 'Description', 'attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
        ->add('eventCapacity', TextType::class, array('label' => 'Event capacity', 'attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
        ->add('eventContact', TextType::class, array('label' => 'Email address', 'attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
        ->add('phoneNO', TextType::class, array('label' => 'Phone number', 'attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
        ->add('Address', TextType::class, array('label' => 'Event address', 'attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
        ->add('eventURL', TextType::class, array('label' => 'Event URL link', 'attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
        ->add('eventType', ChoiceType::class, array('choices' => array('music' => 'music', 'movie' => 'movie', 'theater' => 'theater'),'attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
        ->add('save', SubmitType::class, array('label' => 'Add new event', 'attr' =>array('class' => 'btn btn-primary', 'style' => 'margin-bottom:15px')))
        ->getForm();

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // Get Data
            $name = $form['eventName'] -> getData();
            $eventdate = $form['eventDate'] -> getData();
            $image = $form['eventImg'] -> getData();
            $description = $form['eventDesc'] -> getData();
            $capacity = $form['eventCapacity'] -> getData();
            $email = $form['eventContact'] -> getData();
            $phone = $form['phoneNO'] -> getData();
            $address = $form['Address'] -> getData();
            $url = $form['eventURL'] -> getData();      
            $type = $form['eventType'] -> getData();

            $event -> seteventName($name);
            $event -> seteventDate($eventdate);
            $event -> seteventDesc($description);
            $event -> seteventImg($image);
            $event -> seteventCapacity($capacity);
            $event -> seteventContact($email);
            $event -> setphoneNO($phone);
            $event -> setAddress($address);
            $event -> seteventURL($url);
            $event -> seteventType($type);

            $em = $this -> getDoctrine() -> getManager();

            $em -> persist($event);
            $em -> flush();

            $this -> addFlash(
                'notice',
                'Events Added'
            );

            return $this -> redirectToRoute('homepage');
        }


        return $this->render('events/create.html.twig', array(
            'form' => $form -> createView()
        ));
    }


    /**
     * @Route("/events/edit/{id}", name="event_edit")
     */
    public function editAction($id, Request $request)
    {
        $event = $this->getDoctrine()
        ->getRepository('AppBundle:events')
        ->find($id);


            $event -> seteventName($event->geteventName());
            $event -> seteventDate($event->getEventDate());
            $event -> seteventDesc($event->geteventDesc());
            $event -> seteventImg($event->geteventImg());
            $event -> seteventCapacity($event->geteventCapacity());
            $event -> seteventContact($event->geteventContact());
            $event -> setphoneNO($event->getphoneNO());
            $event -> setAddress($event->getAddress());
            $event -> seteventURL($event->geteventURL());
            $event -> seteventType($event->geteventType());


        $form = $this->createFormBuilder($event)
       ->add('eventName', TextType::class, array('label' => 'Event Name', 'attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
        ->add('eventDate', DateTimeType::class, array('label' => 'Event Date', 'widget' => 'single_text', 'attr' => array('class' => 'form-control', 'style' => 'margin:0 0 15px 0px')))
        ->add('eventDesc', TextareaType::class, array('label' => 'Description', 'attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
        ->add('eventImg', TextType::class, array('label' => 'Event image link', 'attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
        ->add('eventCapacity', TextType::class, array('label' => 'Event headcount capacity', 'attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
        ->add('eventContact', TextType::class, array('label' => 'Email address', 'attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
        ->add('phoneNO', TextType::class, array('label' => 'Phone number', 'attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
        ->add('Address', TextType::class, array('label' => 'Event address', 'attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
        ->add('eventURL', TextType::class, array('label' => 'Event URL link', 'attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
        ->add('eventType', ChoiceType::class, array('choices' => array('music' => 'music', 'movie' => 'movie', 'theater' => 'theater'),'attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
        ->add('save', SubmitType::class, array('label' => 'Modify Event', 'attr' =>array('class' => 'btn btn-success', 'style' => 'margin-bottom:15px')))
        ->getForm();



        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // Get Data
            $name = $form['eventName'] -> getData();
            $eventdate = $form['eventDate'] -> getData();
            $description = $form['eventDesc'] -> getData();
            $image = $form['eventImg'] -> getData();
            $capacity = $form['eventCapacity'] -> getData();
            $email = $form['eventContact'] -> getData();
            $phone = $form['phoneNO'] -> getData();
            $address = $form['Address'] -> getData();
            $url = $form['eventURL'] -> getData();      
            $type = $form['eventType'] -> getData();


            $em = $this -> getDoctrine() -> getManager();
            $event = $em -> getRepository('AppBundle:events') -> find($id);

        
            $event -> seteventName($name);
            $event -> seteventDate($eventdate);
            $event -> seteventDesc($description);
            $event -> seteventImg($image);
            $event -> seteventCapacity($capacity);
            $event -> seteventContact($email);
            $event -> setphoneNO($phone);
            $event -> setAddress($address);
            $event -> seteventURL($url);
            $event -> seteventType($type);


            $em -> flush();

            $this -> addFlash(
                'notice',
                'Event Updated'
            );

            return $this -> redirectToRoute('homepage');
        }


        return $this->render('events/edit.html.twig', array(
            'event' => $event,
            'form' => $form -> createView()
        ));
    }

    /**
     * @Route("/events/details/{id}", name="cars_details")
     */
    public function detailsAction($id)
    {
        $event = $this->getDoctrine()
        ->getRepository('AppBundle:events')
        ->find($id);

        return $this->render('events/details.html.twig', array(
            'event' => $event
        ));
    }

    /**
     * @Route("/events/delete/{id}", name="cars_delete")
     */
    public function deleteAction($id)
    {
            $em = $this -> getDoctrine() -> getManager();
            $event = $em -> getRepository('AppBundle:events') -> find($id);

            $em ->remove($event);
            $em ->flush();


            $this -> addFlash(
                'notice',
                'Event Removed'
            );

            return $this -> redirectToRoute('homepage');
    }


}