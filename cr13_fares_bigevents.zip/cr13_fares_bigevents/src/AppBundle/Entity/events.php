<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * events
 *
 * @ORM\Table(name="events")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\eventsRepository")
 */
class events
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="eventName", type="string", length=255)
     */
    private $eventName;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="eventDate", type="datetime")
     */
    private $eventDate;

    /**
     * @var string
     *
     * @ORM\Column(name="eventDesc", type="string", length=255)
     */
    private $eventDesc;

    /**
     * @var string
     *
     * @ORM\Column(name="eventIMG", type="string", length=255)
     */
    private $eventIMG;

    /**
     * @var int
     *
     * @ORM\Column(name="eventCapacity", type="integer")
     */
    private $eventCapacity;

    /**
     * @var string
     *
     * @ORM\Column(name="eventContact", type="string", length=255)
     */
    private $eventContact;

    /**
     * @var int
     *
     * @ORM\Column(name="phoneNO", type="integer")
     */
    private $phoneNO;

    /**
     * @var string
     *
     * @ORM\Column(name="address", type="string", length=255)
     */
    private $address;

    /**
     * @var string
     *
     * @ORM\Column(name="eventURL", type="string", length=255)
     */
    private $eventURL;

    /**
     * @var string
     *
     * @ORM\Column(name="eventType", type="string", length=255)
     */
    private $eventType;


    /**
     * Get id.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set eventName.
     *
     * @param string $eventName
     *
     * @return events
     */
    public function setEventName($eventName)
    {
        $this->eventName = $eventName;

        return $this;
    }

    /**
     * Get eventName.
     *
     * @return string
     */
    public function getEventName()
    {
        return $this->eventName;
    }

    /**
     * Set eventDate.
     *
     * @param \DateTime $eventDate
     *
     * @return events
     */
    public function setEventDate($eventDate)
    {
        $this->eventDate = $eventDate;

        return $this;
    }

    /**
     * Get eventDate.
     *
     * @return \DateTime
     */
    public function getEventDate()
    {
        return $this->eventDate;
    }

    /**
     * Set eventDesc.
     *
     * @param string $eventDesc
     *
     * @return events
     */
    public function setEventDesc($eventDesc)
    {
        $this->eventDesc = $eventDesc;

        return $this;
    }

    /**
     * Get eventDesc.
     *
     * @return string
     */
    public function getEventDesc()
    {
        return $this->eventDesc;
    }

    /**
     * Set eventIMG.
     *
     * @param string $eventIMG
     *
     * @return events
     */
    public function setEventIMG($eventIMG)
    {
        $this->eventIMG = $eventIMG;

        return $this;
    }

    /**
     * Get eventIMG.
     *
     * @return string
     */
    public function getEventIMG()
    {
        return $this->eventIMG;
    }

    /**
     * Set eventCapacity.
     *
     * @param int $eventCapacity
     *
     * @return events
     */
    public function setEventCapacity($eventCapacity)
    {
        $this->eventCapacity = $eventCapacity;

        return $this;
    }

    /**
     * Get eventCapacity.
     *
     * @return int
     */
    public function getEventCapacity()
    {
        return $this->eventCapacity;
    }

    /**
     * Set eventContact.
     *
     * @param string $eventContact
     *
     * @return events
     */
    public function setEventContact($eventContact)
    {
        $this->eventContact = $eventContact;

        return $this;
    }

    /**
     * Get eventContact.
     *
     * @return string
     */
    public function getEventContact()
    {
        return $this->eventContact;
    }

    /**
     * Set phoneNO.
     *
     * @param int $phoneNO
     *
     * @return events
     */
    public function setPhoneNO($phoneNO)
    {
        $this->phoneNO = $phoneNO;

        return $this;
    }

    /**
     * Get phoneNO.
     *
     * @return int
     */
    public function getPhoneNO()
    {
        return $this->phoneNO;
    }

    /**
     * Set address.
     *
     * @param string $address
     *
     * @return events
     */
    public function setAddress($address)
    {
        $this->address = $address;

        return $this;
    }

    /**
     * Get address.
     *
     * @return string
     */
    public function getAddress()
    {
        return $this->address;
    }

    /**
     * Set eventURL.
     *
     * @param string $eventURL
     *
     * @return events
     */
    public function setEventURL($eventURL)
    {
        $this->eventURL = $eventURL;

        return $this;
    }

    /**
     * Get eventURL.
     *
     * @return string
     */
    public function getEventURL()
    {
        return $this->eventURL;
    }

    /**
     * Set eventType.
     *
     * @param string $eventType
     *
     * @return events
     */
    public function setEventType($eventType)
    {
        $this->eventType = $eventType;

        return $this;
    }

    /**
     * Get eventType.
     *
     * @return string
     */
    public function getEventType()
    {
        return $this->eventType;
    }
}
