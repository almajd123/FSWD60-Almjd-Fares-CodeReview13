<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base.html.twig */
class __TwigTemplate_7125d3a9f93d0b642b32ffd6ae94ba4bb98f5194b6add8bfcbb809e4a778ca59 extends \Twig\Template
{
    private $source;

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
  <head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">
    <link rel=\"icon\" href=\"../../favicon.ico\">

    <title>";
        // line 12
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

    <!-- Bootstrap core CSS -->
    <link href=\"//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css\" rel=\"stylesheet\" id=\"bootstrap-css\">

    <script
      src=\"https://code.jquery.com/jquery-3.3.1.min.js\"
      integrity=\"sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=\"
      crossorigin=\"anonymous\"></script>

    ";
        // line 22
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 23
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />



  </head>

  <body>


<nav class=\"navbar navbar-expand-sm navbar-dark bg-dark py-0\">
  <!-- Brand -->
  <a class=\"navbar-brand py-0\" href=\"#\">Vienna Events</a>

  <!-- Links -->
  <ul class=\"navbar-nav\">
    <li class=\"nav-item py-0\">
      <a class=\"nav-link py-0\" href=\"/events/create\">Add New Event</a>
    </li>
    <li class=\"nav-item\">
      <a class=\"nav-link py-0\" href=\"/\">List Events</a>
    </li>

  </ul>
</nav>


<style>

.navbar{
  font-style: italic;
}


.bg-dark{

  background-color: black!important;
}

    .nopadd {
      
        padding: 0!important;
        margin: 0!important;
        border-radius: 0!important;
        border: 0!important;

     }
    
    .g-cell {
          position: relative;
          text-align: center;
          color : white;
          text-shadow : 2px 2px 4px;
          padding-top: 400px;
          background-image: url(\"https://img.rasset.ie/00110d71-500.jpg\");
          background-size: cover;


    }

.navbar-nav > li > a {
    color: white!important;

}

.navbar-nav > li > a:hover {
      color: white!important;
    background-color: black;
    transition-duration: 0.5s;

    }

.table > tbody > tr > td {
    vertical-align: middle;
}

footer {
    min-height: 100px;
    margin-top: 100px;
    background-color: black;
}

footer li {
    list-style: none;
    font-size: 10px;
    color: white;

}
.col-3{
  color: white;
  text-align: center;
}


</style>


              <div class=\"container-fluid nopadd\">
          
              <div class=\"g-cell g-cell-10-12 g-cell-lg-12-12\">
            <h1 class=\"text-mega text-light text-heading--emphasized\"><p>All Events</p>Bringing the world together through live experiences</h1>
            </div>

    </div>


    <div class=\"container\">




        <div class=\"row\">
            <div class=\"col-md-12\">
                 ";
        // line 135
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 135, $this->source); })()), "session", []), "flashbag", []), "get", [0 => "notice"], "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flash_message"]) {
            // line 136
            echo "                    <div class=\"alert alert-success\">";
            echo twig_escape_filter($this->env, $context["flash_message"], "html", null, true);
            echo "</div>
                 ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flash_message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 138
        echo "

                ";
        // line 140
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 140, $this->source); })()), "session", []), "flashbag", []), "get", [0 => "error"], "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flash_message"]) {
            // line 141
            echo "                    <div class=\"alert alert-danger\">";
            echo twig_escape_filter($this->env, $context["flash_message"], "html", null, true);
            echo "</div>
                 ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flash_message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 143
        echo "            </div>
        </div>


            
                 ";
        // line 148
        $this->displayBlock('body', $context, $blocks);
        // line 149
        echo "    



        </div><!-- /.container -->


  </body>


<footer class=\"pt-2\">

    <div class=\"container\">
            <div class=\"row\">
                        
               
                    
                    <div class=\"col-3 offset-5\">
                        <img src=\"https://modernhomedecor.eu/wp-content/uploads/2018/02/The-Top-Design-Events-of-2018-22.jpg\" alt=\"Holi\" width=\"190px\">
                      <p>Almajd Fares&copy;</p>
                    </div>
            </div>       
    </div>

 ";
        // line 173
        $this->displayBlock('javascripts', $context, $blocks);
        echo "   
</footer>

</html>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 12
    public function block_title($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 22
    public function block_stylesheets($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 148
    public function block_body($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 173
    public function block_javascripts($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  320 => 173,  303 => 148,  286 => 22,  268 => 12,  254 => 173,  228 => 149,  226 => 148,  219 => 143,  210 => 141,  206 => 140,  202 => 138,  193 => 136,  189 => 135,  73 => 23,  71 => 22,  58 => 12,  45 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html lang=\"en\">
  <head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">
    <link rel=\"icon\" href=\"../../favicon.ico\">

    <title>{% block title %}Welcome!{% endblock %}</title>

    <!-- Bootstrap core CSS -->
    <link href=\"//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css\" rel=\"stylesheet\" id=\"bootstrap-css\">

    <script
      src=\"https://code.jquery.com/jquery-3.3.1.min.js\"
      integrity=\"sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=\"
      crossorigin=\"anonymous\"></script>

    {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />



  </head>

  <body>


<nav class=\"navbar navbar-expand-sm navbar-dark bg-dark py-0\">
  <!-- Brand -->
  <a class=\"navbar-brand py-0\" href=\"#\">Vienna Events</a>

  <!-- Links -->
  <ul class=\"navbar-nav\">
    <li class=\"nav-item py-0\">
      <a class=\"nav-link py-0\" href=\"/events/create\">Add New Event</a>
    </li>
    <li class=\"nav-item\">
      <a class=\"nav-link py-0\" href=\"/\">List Events</a>
    </li>

  </ul>
</nav>


<style>

.navbar{
  font-style: italic;
}


.bg-dark{

  background-color: black!important;
}

    .nopadd {
      
        padding: 0!important;
        margin: 0!important;
        border-radius: 0!important;
        border: 0!important;

     }
    
    .g-cell {
          position: relative;
          text-align: center;
          color : white;
          text-shadow : 2px 2px 4px;
          padding-top: 400px;
          background-image: url(\"https://img.rasset.ie/00110d71-500.jpg\");
          background-size: cover;


    }

.navbar-nav > li > a {
    color: white!important;

}

.navbar-nav > li > a:hover {
      color: white!important;
    background-color: black;
    transition-duration: 0.5s;

    }

.table > tbody > tr > td {
    vertical-align: middle;
}

footer {
    min-height: 100px;
    margin-top: 100px;
    background-color: black;
}

footer li {
    list-style: none;
    font-size: 10px;
    color: white;

}
.col-3{
  color: white;
  text-align: center;
}


</style>


              <div class=\"container-fluid nopadd\">
          
              <div class=\"g-cell g-cell-10-12 g-cell-lg-12-12\">
            <h1 class=\"text-mega text-light text-heading--emphasized\"><p>All Events</p>Bringing the world together through live experiences</h1>
            </div>

    </div>


    <div class=\"container\">




        <div class=\"row\">
            <div class=\"col-md-12\">
                 {% for flash_message in app.session.flashbag.get('notice') %}
                    <div class=\"alert alert-success\">{{flash_message}}</div>
                 {% endfor %}


                {% for flash_message in app.session.flashbag.get('error') %}
                    <div class=\"alert alert-danger\">{{flash_message}}</div>
                 {% endfor %}
            </div>
        </div>


            
                 {% block body %}{% endblock %}
    



        </div><!-- /.container -->


  </body>


<footer class=\"pt-2\">

    <div class=\"container\">
            <div class=\"row\">
                        
               
                    
                    <div class=\"col-3 offset-5\">
                        <img src=\"https://modernhomedecor.eu/wp-content/uploads/2018/02/The-Top-Design-Events-of-2018-22.jpg\" alt=\"Holi\" width=\"190px\">
                      <p>Almajd Fares&copy;</p>
                    </div>
            </div>       
    </div>

 {% block javascripts %}{% endblock %}   
</footer>

</html>", "base.html.twig", "D:\\xampp\\htdocs\\cr13_fares_bigevents\\app\\Resources\\views\\base.html.twig");
    }
}
