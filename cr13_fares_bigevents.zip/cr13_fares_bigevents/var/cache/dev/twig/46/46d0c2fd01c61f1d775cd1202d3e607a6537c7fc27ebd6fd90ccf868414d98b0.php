<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* events/index.html.twig */
class __TwigTemplate_03765277f568e84fe61c0f8c407cd1d5a0a956bc358059f7fd2367a9d103343d extends \Twig\Template
{
    private $source;

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "events/index.html.twig", 1);
        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "events/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "events/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = [])
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
<style>
 
.myboxcenter { 
\t
\tdisplay: flex;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: center;
    align-items: center;
\tborder-radius: 10px;

      }
 


</style>

\t\t<div class=\"row\">
\t
\t\t";
        // line 24
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["events"]) || array_key_exists("events", $context) ? $context["events"] : (function () { throw new RuntimeError('Variable "events" does not exist.', 24, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["event"]) {
            // line 25
            echo "\t
     <div class=\"col-md-4 mx-auto ";
            // line 26
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "eventType", []), "html", null, true);
            echo "\">
\t         <div class=\"card mb-4 text-white bg-dark\">
\t            <img class=\"card-img-top\" src=\"";
            // line 28
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "eventImg", []), "html", null, true);
            echo "\" height=\"250px\" alt=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "eventName", []), "html", null, true);
            echo "\">
\t            <div class=\"card-body\">
\t               <h5 class=\"card-title\">";
            // line 30
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "eventName", []), "html", null, true);
            echo "</h5>
\t               <p class=\"card-text\">";
            // line 31
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "Address", []), "html", null, true);
            echo " <br> ";
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "eventDate", []), "F j, y, g:i a"), "html", null, true);
            echo "</p>
\t               <a href=\"/events/details/";
            // line 32
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "id", []), "html", null, true);
            echo "\" class=\"btn btn-outline-light btn-sm\">See Details</a>
\t               <a href=\"/events/edit/";
            // line 33
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "id", []), "html", null, true);
            echo "\" class=\"btn btn-outline-light btn-sm\">Edit Event</a>
\t               <a href=\"/events/delete/";
            // line 34
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "id", []), "html", null, true);
            echo "\" class=\"btn btn-outline-light btn-sm\">Delete Event</a>
\t            </div>
\t         </div>
\t      </div>


\t  
\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['event'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 41
        echo " 

\t\t</div>



";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "events/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 41,  124 => 34,  120 => 33,  116 => 32,  110 => 31,  106 => 30,  99 => 28,  94 => 26,  91 => 25,  87 => 24,  65 => 4,  56 => 3,  27 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block body %}

<style>
 
.myboxcenter { 
\t
\tdisplay: flex;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: center;
    align-items: center;
\tborder-radius: 10px;

      }
 


</style>

\t\t<div class=\"row\">
\t
\t\t{% for event in events %}
\t
     <div class=\"col-md-4 mx-auto {{event.eventType}}\">
\t         <div class=\"card mb-4 text-white bg-dark\">
\t            <img class=\"card-img-top\" src=\"{{event.eventImg}}\" height=\"250px\" alt=\"{{event.eventName}}\">
\t            <div class=\"card-body\">
\t               <h5 class=\"card-title\">{{event.eventName}}</h5>
\t               <p class=\"card-text\">{{event.Address}} <br> {{event.eventDate|date('F j, y, g:i a')}}</p>
\t               <a href=\"/events/details/{{event.id}}\" class=\"btn btn-outline-light btn-sm\">See Details</a>
\t               <a href=\"/events/edit/{{event.id}}\" class=\"btn btn-outline-light btn-sm\">Edit Event</a>
\t               <a href=\"/events/delete/{{event.id}}\" class=\"btn btn-outline-light btn-sm\">Delete Event</a>
\t            </div>
\t         </div>
\t      </div>


\t  
\t\t{% endfor %} 

\t\t</div>



{% endblock %}", "events/index.html.twig", "D:\\xampp\\htdocs\\cr13_fares_bigevents\\app\\Resources\\views\\events\\index.html.twig");
    }
}
